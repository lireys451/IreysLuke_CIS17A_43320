
#include <iostream>
#include <string>
using namespace std;

struct AccountBalance
{
    string name,
           adrs,
           acntNum;
    float blnc,
          *wthdrw,
          *dpst;
};

void getData(AccountBalance &, float &, float &);
void displayData(AccountBalance &, float, float);
void calculate(AccountBalance &, float, float);

int main() 
{
    struct AccountBalance acnt;
    
    float dpstTotal = 0;
    float wthdrwTotal = 0;
    
    getData(acnt, wthdrwTotal, dpstTotal);
    displayData(acnt, wthdrwTotal, dpstTotal);
    calculate(acnt, wthdrwTotal, dpstTotal);
    
    
    delete[] acnt.wthdrw;
    delete[] acnt.dpst;
    return 0;
}

void getData(AccountBalance &acnt, float &wthdrwTotal, float &dpstTotal)
{
    int chks;
    int dpsts;
    acnt.wthdrw = new float[chks];
    acnt.dpst = new float[dpsts];
    
    cout << "Enter Name: ";
    getline(cin, acnt.name);
    cout << "Enter Address: ";
    getline(cin, acnt.adrs);
    cout << "Enter 5 Digit Account Number: ";
    getline(cin, acnt.acntNum);
    while(acnt.acntNum.length() != 5)
    {
        cout << "Account number must be 5 digits. Please try again: ";
        getline(cin, acnt.acntNum);
    }
    cout << "Enter Balance at the Beginning of the Month: ";
    cin >> acnt.blnc;
    cout << "Enter Total Checks Written: ";
    cin >> chks;
    cout << "Enter Amount Withdrawn Per Check: ";
    for(int i = 0; i < chks; i++) 
    {
        cin >> *(acnt.wthdrw + i);
        wthdrwTotal += *(acnt.wthdrw + i);
    } 
    cout << "Enter Total Checks Deposited: ";
    cin >> dpsts;
    cout << "Enter Amount Deposited Per Check: ";
    for(int j = 0; j < dpsts; j++) 
    {
        cin >> *(acnt.dpst + j);
        dpstTotal += *(acnt.dpst + j);
    }
}

void displayData(AccountBalance &acnt, float wthdrwTotal, float dpstTotal)
{
    cout << endl << "Name: ";
    cout << acnt.name << endl;
    cout << "Address: ";
    cout << acnt.adrs << endl;
    cout << "Account Number: ";
    cout << acnt.acntNum << endl;
    cout << "Balance at the Beginning of the Month: $";
    cout << acnt.blnc << endl;
    cout << "Amount Withdrawn: $";
    cout << wthdrwTotal << endl;
    cout << "Amount Deposited: $";  
    cout << dpstTotal << endl;
}

void calculate(AccountBalance &acnt, float wthdrwTotal, float dpstTotal)
{
    float balance = acnt.blnc;
    
    float ttl = balance + dpstTotal - wthdrwTotal;
    
    if (ttl >= 0)
    {
        cout << endl << "Account Balance: $" << ttl;
    }
    
    else
    {
        cout << endl << "Account Balance: $" << ttl;
        ttl -= 20;
        cout << endl << "Your account is overdrawn. You will be charged an additional $20 fee."
             << endl << "New Balance: $" << ttl;
    }
}
