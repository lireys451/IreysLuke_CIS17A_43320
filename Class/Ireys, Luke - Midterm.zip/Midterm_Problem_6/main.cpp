
#include <iostream>
using namespace std;

int main() {

    cout << "Part A:" << endl << endl
         << "Base 10: 2.875" << endl 
         << "Base 16: 2.E" << endl
         << "Base 2: 10.111" << endl
         << "Base 8: 2.7" << endl
         << "Float Representation: 5C000002" << endl << endl;
    
    cout << "Base 10: 0.1796875" << endl
         << "Base 16: 0.2E" << endl
         << "Base 2: 0.0010111" << endl
         << "Base 8: 0.134" << endl
         << "Float Representation: 5C0000FE" <<endl
         << "-------------------------------" << endl;
    
    cout << "Part B:" << endl << endl
         << "Base 10: -2.875" << endl 
         << "Base 16: D.2" << endl
         << "Base 2: 1110.001" << endl
         << "Base 8: 16.1" << endl
         << "Float Representation: 71000004" << endl << endl;
    
    cout << "Base 10: -0.1796875" << endl
         << "Base 16: 0.E2" << endl
         << "Base 2: 0.1110001" << endl
         << "Base 8: 0.704" << endl
         << "Float Representation: 71000000" <<endl
         << "-------------------------------" << endl;
    
    cout << "Part C:" << endl << endl
         << "Float Representation: 59999901" << endl
         << "Base 2: 1.011001" << endl
         << "Base 10: 1.39063" << endl << endl;
    
    cout << "Float Representation: 59999902" << endl
         << "Base 2: 10.11001" << endl
         << "Base 10: 2.78125" << endl << endl;
    
    cout << "Float Representation: A66667FE" << endl
         << "Base 2: 0.0101001100110011001100111" << endl
         << "Base 10: 0.32500001788139343262" << endl << endl;
    return 0;
}

