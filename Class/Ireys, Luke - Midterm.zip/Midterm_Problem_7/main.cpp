#include <cstdlib>
#include <iomanip>
#include <iostream>

using namespace std;

struct Prime{
    unsigned short prime;
    unsigned char power;
};

struct Primes{
    unsigned char nPrimes;
    Prime *prime;
};

Primes *factor(int);
void prntPrm(Primes *);

int main() 
{    
    int n;
  do{
    cout << "Input a number between 2 and 10,000: ";
    cin >> n;
    cout << endl;
  }while(n < 2 || n > 10000);

  Primes *primes = factor(n);
  cout << n;
  prntPrm(primes);
  
  return 0;

}

Primes *factor(int n){
  Prime *p = new Prime[5];
  int count = 0;
  unsigned char nPrimes = 0;
  unsigned char power = 0;

  while(n % 2 == 0){
    cout << "(" << n << "/" << 2 << ") " << n/2 << endl;
    n /= 2;
    power++;
    p[0] = {2, power};
  }

  if(p[0].prime == 2){
    count++;
  }

  for(unsigned short i = 3; i <= n; i = i+2){
    power = 0;
    while(n % i == 0){
      n /= i;
      power++;
    }
    if(power != 0){
      p[count] = {i, power};
      count++;
      nPrimes++;
    }
  }

  Primes *primes = new Primes{nPrimes, p};
  return primes;
}

void prntPrm(Primes *p){

  cout << " = ";
  for(int i = 0; i <= p->nPrimes; i++){
    cout << int(p->prime[i].prime) << "^" << int(p->prime[i].power);
    if(i != p->nPrimes){
      cout << " * ";
    }
  }
  cout << "\n";
}