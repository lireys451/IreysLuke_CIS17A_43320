
#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

struct EmployeeInfo
{
    string comp,
           adrs,
           name,
           amntEng,
           sign;
    float amntNum,
          rate,
          hrs;
};

void getData(EmployeeInfo *, int &);
void calcData(EmployeeInfo *, int);
void displayData(EmployeeInfo *, int);


int main() 
{
    struct EmployeeInfo *info;
    
    int emplys;
    cout << "Enter Number of Employees: ";
    cin >> emplys;
    cout << endl;
    
    info = new EmployeeInfo[emplys];
    
    getData(info, emplys);
    calcData(info, emplys);
    displayData(info, emplys);
    
    delete []info;
    
    
    return 0;
}

void getData(EmployeeInfo *info, int &emplys)
{
    
    
    
    for(int i = 0; i < emplys; i++)
    {
        cout << "Enter Company Name: ";
        cin.ignore();
        getline(cin, info[i].comp);
        cout << "Enter Address: ";
        getline(cin, info[i].adrs);
        cout << "Enter Recipient: ";
        getline(cin, info[i].name);
        cout << "Enter Digital Signature: ";
        getline(cin,info[i].sign);
        cout << "Enter Pay Rate Per Hour: ";
        cin >> info[i].rate;
        cout << "Enter Hours Worked: ";
        cin >> info[i].hrs;
        cout << endl;
    }
}

void calcData(EmployeeInfo *info, int emplys)
{
    for(int i = 0; i < emplys; i++){
        
    float ttl;
    float nrmlPay = 40 * info[i].rate;
    float dblPay = (10 * info[i].rate) * 2;
    
    if (info[i].hrs <= 40)
    ttl = info[i].rate * info[i].hrs;
    
    else if(info[i].hrs > 40 && info[i].hrs <=50)
    ttl = nrmlPay + ((info[i].hrs - 40) * info[i].rate) * 2;
    
    else
    ttl = nrmlPay + dblPay + ((info[i].hrs - 50) * info[i].rate) * 3;
     
    info[i].amntNum = ttl;
    
    unsigned char n1000s,n100s,n10s,n1s;
        int newttl = static_cast<int>(ttl);
        n1000s=newttl/1000;
        n100s=newttl%1000/100;
        n10s=newttl%100/10;
        n1s=newttl%10;

    info[i].amntEng += (n1000s==9?"Nine Thousand ":
                    n1000s==8?"Eight Thousand ":
                    n1000s==7?"Seven Thousand ":
                    n1000s==6?"Six Thousand ":
                    n1000s==5?"Five Thousand ":
                    n1000s==4?"Four Thousand ":
                    n1000s==3?"Three Thousand ":
                    n1000s==2?"Two Thousand ":
                    n1000s==1?"One Thousand ": "");
               
    info[i].amntEng += (n100s==9?"Nine Hundred ":
                    n100s==8?"Eight Hundred ":
                    n100s==7?"Seven Hundred ":
                    n100s==6?"Six Hundred ":
                    n100s==5?"Five Hundred ":
                    n100s==4?"Four Hundred ":
                    n100s==3?"Three Hundred ":
                    n100s==2?"Two Hundred ":
                    n100s==1?"One Hundred ": "");
               
    info[i].amntEng += (n10s==9?"Ninety ":
                    n10s==8?"Eighty ":
                    n10s==7?"Seventy ":
                    n10s==6?"Sixty ":
                    n10s==5?"Fifty ":
                    n10s==4?"Forty ":
                    n10s==3?"Thirty ":
                    n10s==2?"Twenty ": "");
               
    info[i].amntEng += ((n10s==1 && n1s == 9)?"Nineteen":
                    (n10s==1 && n1s == 8)?"Eighteen":
                    (n10s==1 && n1s == 7)?"Seventeen":
                    (n10s==1 && n1s == 6)?"Sixteen":
                    (n10s==1 && n1s == 5)?"Fifteen":
                    (n10s==1 && n1s == 4)?"Fourteen":
                    (n10s==1 && n1s == 3)?"Thirteen":
                    (n10s==1 && n1s == 2)?"Twelve":
                    (n10s==1 && n1s == 1)?"Eleven":
                    (n10s==1 && n1s == 0)?"Ten":
               
                    (n10s!=1 && n1s == 9)?"Nine":
                    (n10s!=1 && n1s == 8)?"Eight":
                    (n10s!=1 && n1s == 7)?"Seven":
                    (n10s!=1 && n1s == 6)?"Six":
                    (n10s!=1 && n1s == 5)?"Five":
                    (n10s!=1 && n1s == 4)?"Four":
                    (n10s!=1 && n1s == 3)?"Three":
                    (n10s!=1 && n1s == 2)?"Two":
                    (n10s!=1 && n1s == 1)?"One": "");
    
    }

}

void displayData(EmployeeInfo *info, int emplys)
{
    for (int i = 0; i < emplys; i++){
        
    cout << info[i].comp << endl;
    cout << info[i].adrs << endl;
    cout << "Name: " << info[i].name << "          "; 
    cout << "Amount: $" << fixed << setprecision(2) << info[i].amntNum << endl;
    cout << "Amount: " << info[i].amntEng << " Dollars" << endl;
    cout << "Signature Line: " << info[i].sign << endl <<endl;
    }
    
}