#include <iostream>
#include <string>
using namespace std;

void getData();
void encrypt(char [], const int);
void decrypt(char [], const int);

int main() {
    
    getData();
    
    return 0;
}

void getData()
{
    const int SIZE = 4;
    char code[SIZE];
    bool path;
    
    cout << "Enter 4-Digit Code Using Only 0-7: ";
    
    cin >> code;
 
    while (code[0] > '7' || code[0] < '0' || code[1] > '7' || code[1] < '0' || code[2] > '7' || code[2] < '0' || code[3] > '7' || code[3] < '0')
    {
        cout << "Invalid input. Code must only use numbers between 0-7. Please try again: ";
        cin >> code;
    }
 
    cout << "Encrypt (0) or Decrypt (1): ";
    cin >> path; 
    if(path == false)
        encrypt(code, SIZE);
    else if(path == true)
        decrypt(code, SIZE);
            
    
}

void encrypt(char code[], const int SIZE)
{
    
    for (int i = 0; i < SIZE; i ++)
    {
        unsigned char temp1 = code[i];
        int temp2 = temp1 - '0';
        temp2 += 5;
        temp2 = temp2 % 8;
        temp1 = '0' + temp2;
        code[i] = temp1;
    }
    
    char swap1;
    swap1 = code[0];
    code[0] = code[2];
    code[2] = swap1;
    
    char swap2;
    swap2 = code[1];
    code[1] = code[3];
    code[3] = swap2;

    
    cout << "New Code: " << code << endl ;
}

void decrypt(char code[], const int SIZE)
{
    char swap1;
    swap1 = code[0];
    code[0] = code[2];
    code[2] = swap1;
    
    char swap2;
    swap2 = code[1];
    code[1] = code[3];
    code[3] = swap2;
    
    for (int i = 0; i < SIZE; i ++)
    {
        unsigned char temp1 = code[i];
        int temp2 = temp1 - '0';
        if (temp2 < 5)
        {
            temp2 += 8;
        }
        temp2 -= 5;
        temp1 = '0' + temp2;
        code[i] = temp1;
    }
    
    cout << "New Code: " << code << endl;
}