
#include <iostream>
using namespace std;


int main() {

    cout << "Integer overflows when n = 13" << endl;
    cout << "Unsigned integer overflows when n = 13" << endl;
    cout << "Character overflows when n = 4" << endl;
    cout << "Unsigned Character overflows when n = 4" << endl;
    cout << "Short overflows when n = 8" << endl;
    cout << "Unsigned short overflows when n = 9" << endl;
    cout << "Float overflows when n = 35" << endl;
    cout << "Double overflows when n = 171" << endl;


    unsigned char num;
	cout<<"Enter Number To Find Its Factorial: ";
	cin>>num;
	cout << num;

	return 0;
}

